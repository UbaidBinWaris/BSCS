#include "Node.h"

Node::Node() {
    next = nullptr;
    prev = nullptr;
}



