package com.example.postrequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostRequestApplicationTests {

    @Test
    void contextLoads() {
    }

}
