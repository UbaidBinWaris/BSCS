package com.example.getrequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetRequestApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetRequestApplication.class, args);
	}

}
