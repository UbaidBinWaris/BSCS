package com.example.getrequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
