package com.example.service;

import com.example.repository.UserInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
@RequiredArgs
public class UserInfoService {

    private final UserInfoRepository userInfoRepository;
}
